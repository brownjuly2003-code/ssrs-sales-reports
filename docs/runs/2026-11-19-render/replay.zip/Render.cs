using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using Microsoft.Reporting.WinForms;

public class Input {
    public Dictionary<string, Dictionary<string, object>[]> Data { get; set; }
    public Dictionary<string, string[]> Parameters { get; set; }
}

class Render {
    static int Main(string[] args) {
        Console.OutputEncoding = new UTF8Encoding(false);
        Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo("ru-RU");
        try {
            foreach (string inputPath in args.Skip(1)) {
                var input = new JavaScriptSerializer().Deserialize<Input>(File.ReadAllText(inputPath));
                using (var report = new LocalReport()) {
                    report.ReportPath = args[0];
                    foreach (var pair in input.Data) {
                        var table = new DataTable(pair.Key);
                        foreach (var column in pair.Value.First()) {
                            table.Columns.Add(column.Key, column.Value.GetType());
                        }
                        foreach (var item in pair.Value) {
                            var row = table.NewRow();
                            foreach (var field in item) row[field.Key] = field.Value;
                            table.Rows.Add(row);
                        }
                        report.DataSources.Add(new ReportDataSource(pair.Key, table));
                    }
                    report.SetParameters(input.Parameters.Select(p => new ReportParameter(p.Key, p.Value)));
                    foreach (var format in new[] {"PDF", "EXCELOPENXML"}) {
                        Warning[] warnings;
                        string mime, encoding, extension;
                        string[] streams;
                        var bytes = report.Render(format, null, out mime, out encoding, out extension, out streams, out warnings);
                        Console.WriteLine("{0} {1} {2} bytes warnings={3}", inputPath, extension, bytes.Length, warnings.Length);
                        foreach (var warning in warnings) Console.WriteLine(warning.Code + ": " + warning.Message);
                        File.WriteAllBytes(Path.ChangeExtension(inputPath, extension), bytes);
                    }
                }
            }
            return 0;
        } catch (Exception error) {
            for (; error != null; error = error.InnerException) Console.Error.WriteLine(error.GetType().Name + ": " + error.Message);
            return 1;
        }
    }
}
